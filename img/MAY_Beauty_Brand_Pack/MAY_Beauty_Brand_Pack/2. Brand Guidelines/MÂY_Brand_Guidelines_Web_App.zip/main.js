document.addEventListener('DOMContentLoaded', () => {
    
    // ==========================================
    // 1. CUSTOM LUXURY CURSOR FOLLOW SYSTEM
    // ==========================================
    const cursorOutline = document.querySelector('.custom-cursor');
    const cursorDot = document.querySelector('.custom-cursor-dot');
    
    let mouseX = 0, mouseY = 0; // Current mouse coords
    let outlineX = 0, outlineY = 0; // Outer circle coords (smoothed)
    const smoothFactor = 0.15; // Smooth lag factor (lerp)

    window.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Dot moves instantly
        cursorDot.style.left = mouseX + 'px';
        cursorDot.style.top = mouseY + 'px';
    });

    // Lerp loop for the smooth outer circle cursor
    function animateCursor() {
        outlineX += (mouseX - outlineX) * smoothFactor;
        outlineY += (mouseY - outlineY) * smoothFactor;
        
        cursorOutline.style.left = outlineX + 'px';
        cursorOutline.style.top = outlineY + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    animateCursor();

    // Hover state effects
    const hoverElements = document.querySelectorAll('a, button, .swatch-card, .material-btn, .lightbox-trigger, input, .toggle-switch');
    hoverElements.forEach(elem => {
        elem.addEventListener('mouseenter', () => {
            cursorOutline.classList.add('hovered');
        });
        elem.addEventListener('mouseleave', () => {
            cursorOutline.classList.remove('hovered');
        });
    });


    // ==========================================
    // 2. TOAST NOTIFICATION
    // ==========================================
    const toast = document.getElementById('toast');
    let toastTimeout;

    function showToast(message) {
        toast.textContent = message;
        toast.classList.add('show');
        
        clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 2500);
    }


    // ==========================================
    // 3. GOLD DUST CANVAS PARTICLE SYSTEM (3D Depth)
    // ==========================================
    const canvas = document.getElementById('gold-dust-canvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let particles = [];
        const particleCount = 180;

        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }

        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        class Particle {
            constructor(x, y, manual = false) {
                this.x = x || Math.random() * canvas.width;
                this.y = y || Math.random() * canvas.height;
                this.z = Math.random() * 3 + 0.4; // depth parallax
                this.size = this.z * 1.3;
                
                // Slow drift speed based on depth
                this.speedX = ((Math.random() * 0.8 - 0.4) / this.z);
                // Float upwards
                this.speedY = ((Math.random() * -1.2 - 0.3) / this.z);
                
                // Gold palette
                const colors = ['#D4AF37', '#F3E5AB', '#CFB53B', '#FFDF00', '#C5B358', '#E7C7DC'];
                this.color = colors[Math.floor(Math.random() * colors.length)];
                
                // Opacity limits
                this.opacity = (Math.random() * 0.5 + 0.3) / this.z;
                this.twinkleDirection = Math.random() > 0.5 ? 0.015 : -0.015;
            }

            update() {
                this.x += this.speedX;
                this.y += this.speedY;

                // Subtle twinkling opacity
                this.opacity += this.twinkleDirection;
                if (this.opacity >= 0.8 / this.z || this.opacity <= 0.1) {
                    this.twinkleDirection = -this.twinkleDirection;
                }

                // If particle exits the top
                if (this.y < -10) {
                    this.y = canvas.height + 10;
                    this.x = Math.random() * canvas.width;
                    this.opacity = (Math.random() * 0.5 + 0.3) / this.z;
                }
                
                // Wrap around X
                if (this.x < -10) this.x = canvas.width + 10;
                if (this.x > canvas.width + 10) this.x = -10;
            }

            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = this.color;
                ctx.globalAlpha = Math.max(0, Math.min(1, this.opacity));
                
                // Light glow
                ctx.shadowBlur = 12;
                ctx.shadowColor = this.color;
                
                ctx.fill();
                ctx.shadowBlur = 0; // reset for rendering speed
                ctx.globalAlpha = 1;
            }
        }

        // Initialize particles
        function init() {
            particles = [];
            for (let i = 0; i < particleCount; i++) {
                particles.push(new Particle());
            }
        }

        // Generate extra gold dust on mouse hover inside hero
        const heroSection = document.querySelector('.hero');
        heroSection.addEventListener('mousemove', (e) => {
            // Spawn 1 extra particle occasionally on cursor trajectory
            if (Math.random() < 0.25) {
                particles.push(new Particle(e.clientX, e.clientY, true));
                if (particles.length > particleCount + 50) {
                    particles.shift(); // keep particle count bounded
                }
            }
        });

        // Animation Loop
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(p => {
                p.update();
                p.draw();
            });
            requestAnimationFrame(animate);
        }

        init();
        animate();
    }


    // ==========================================
    // 4. 3D HERO LOGO MOVE TILT EFFECT
    // ==========================================
    const heroLogo = document.querySelector('.hero-logo');
    const heroContent = document.querySelector('.hero-content');
    
    if (heroLogo && heroContent) {
        heroContent.addEventListener('mousemove', (e) => {
            const rect = heroContent.getBoundingClientRect();
            // Get center coordinates of the card
            const cardX = rect.left + rect.width / 2;
            const cardY = rect.top + rect.height / 2;
            
            // Mouse distance from center
            const angleX = -(e.clientY - cardY) / 20;
            const angleY = (e.clientX - cardX) / 20;
            
            heroLogo.style.transform = `rotateX(${angleX}deg) rotateY(${angleY}deg) scale(1.02)`;
        });

        heroContent.addEventListener('mouseleave', () => {
            heroLogo.style.transform = 'rotateX(0deg) rotateY(0deg) scale(1)';
        });
    }


    // ==========================================
    // 5. NAVBAR SCROLL EFFECT
    // ==========================================
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });


    // ==========================================
    // 6. BRAND GUIDELINES TAB CONTROL
    // ==========================================
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from buttons
            tabBtns.forEach(b => b.classList.remove('active'));
            // Hide all contents
            tabContents.forEach(c => c.classList.remove('active'));

            // Set current active
            btn.classList.add('active');
            const tabId = btn.getAttribute('data-tab') + '-tab';
            document.getElementById(tabId).classList.add('active');
        });
    });


    // ==========================================
    // 7. COLOR LABORATORY - CLICK TO COPY
    // ==========================================
    const swatchCards = document.querySelectorAll('.swatch-card');
    swatchCards.forEach(card => {
        card.addEventListener('click', () => {
            const hex = card.getAttribute('data-hex');
            navigator.clipboard.writeText(hex).then(() => {
                showToast(`Hex code ${hex} copied to clipboard!`);
            }).catch(err => {
                console.error('Could not copy color: ', err);
            });
        });
    });


    // ==========================================
    // 8. TYPOGRAPHY PLAYGROUND INPUT SYNC
    // ==========================================
    const brandInput = document.getElementById('brand-text-input');
    const headingDisplay = document.getElementById('heading-font-display');
    const bodyDisplay = document.getElementById('body-font-display');

    if (brandInput && headingDisplay && bodyDisplay) {
        brandInput.addEventListener('input', (e) => {
            const textVal = e.target.value || "YOUR BEAUTY, OUR PROMISE";
            headingDisplay.textContent = textVal;
            bodyDisplay.textContent = textVal;
        });
    }


    // ==========================================
    // 9. SIGNAGE MATERIAL SIMULATOR
    // ==========================================
    const materialBtns = document.querySelectorAll('.material-btn');
    const materialPlates = document.querySelectorAll('.material-plate');
    const backlightToggle = document.getElementById('backlight-toggle');
    const signageGlow = document.querySelector('.signage-ambient-glow');
    const signageLogo = document.querySelector('.signage-logo-mesh');

    materialBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            materialBtns.forEach(b => b.classList.remove('active'));
            materialPlates.forEach(p => p.classList.remove('active'));

            btn.classList.add('active');
            const targetMaterial = btn.getAttribute('data-material');
            document.getElementById(`plate-${targetMaterial}`).classList.add('active');
        });
    });

    if (backlightToggle && signageGlow && signageLogo) {
        backlightToggle.addEventListener('change', (e) => {
            if (e.target.checked) {
                signageGlow.style.opacity = '1';
                signageLogo.style.filter = 'drop-shadow(0 0 10px rgba(212, 175, 55, 0.7))';
                signageLogo.style.opacity = '1';
            } else {
                signageGlow.style.opacity = '0';
                signageLogo.style.filter = 'none';
                signageLogo.style.opacity = '0.8';
            }
        });
    }


    // ==========================================
    // 10. CUSTOM LIGHTBOX SYSTEM
    // ==========================================
    const lightboxModal = document.getElementById('lightbox-modal');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxTriggers = document.querySelectorAll('.lightbox-trigger');
    const lightboxClose = document.querySelector('.lightbox-close');

    lightboxTriggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const imagePath = trigger.getAttribute('data-src');
            lightboxImg.src = imagePath;
            lightboxModal.classList.add('show');
            cursorOutline.classList.remove('hovered'); // fix hover outline lock
        });
    });

    function closeLightbox() {
        lightboxModal.classList.remove('show');
    }

    if (lightboxClose) {
        lightboxClose.addEventListener('click', closeLightbox);
    }
    if (lightboxModal) {
        lightboxModal.addEventListener('click', (e) => {
            if (e.target === lightboxModal) {
                closeLightbox();
            }
        });
    }
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeLightbox();
        }
    });

});
